ENTREGA 2 - DIEGO BERMEJO, MARC CAÑELLAS, GASTON PANIZZA

Mejoras Realizadas: hemos usado una caché de directorios para optimizar la escritura.

Observaciones: los nombres de los comandos son los mismos que se declaran en los documentos con 
los enunciados